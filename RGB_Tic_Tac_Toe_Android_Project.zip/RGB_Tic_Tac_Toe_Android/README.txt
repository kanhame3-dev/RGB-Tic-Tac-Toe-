RGB TIC TAC TOE - ANDROID PROJECT
================================

Included features
- Ultra Pro RGB/neon gaming interface
- Play vs Computer mode
- Two-player local mode
- Computer difficulty: Pro (unbeatable minimax) and Rookie
- Scoreboard for X, O/Computer and draws
- Score persistence on the device
- Sound effects with sound on/off
- Five colour themes
- Winning-line animation and result messages
- Android WebView wrapper; game assets are bundled offline

HOW TO OPEN
1. Install Android Studio on a computer.
2. Extract this ZIP file.
3. In Android Studio choose Open and select the extracted RGB_Tic_Tac_Toe_Android folder.
4. Let Gradle sync. Use JDK 17 if Android Studio asks.
5. Run on an Android phone/emulator to test.

HOW TO CREATE A PLAY STORE FILE
1. In Android Studio select Build > Generate Signed Bundle / APK.
2. Choose Android App Bundle (AAB).
3. Create and safely back up a signing key/keystore. Never share it.
4. Build the release bundle and test it.
5. Upload the AAB in Google Play Console and complete the store listing,
   content rating, Data safety and other required declarations.

IMPORTANT
- This is a starter Android Studio project, not a finished signed AAB.
- Test on real devices before publishing. Verify current Play Console target API,
  testing, identity and account requirements at Google's official documentation.
- Google Play developer account registration requires the account holder to meet
  Google's age and verification rules. If you are under 18, ask a parent/guardian
  to handle the developer account and publishing.
- App currently uses no network connection and no ads or analytics.
